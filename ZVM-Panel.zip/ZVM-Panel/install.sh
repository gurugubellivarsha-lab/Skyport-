#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./install.sh"; exit 1; fi
apt-get update
apt-get install -y python3 python3-pip python3-venv docker.io socat
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  systemctl enable --now docker || true
else
  echo "systemd not detected; start Docker using your host/container runtime."
fi
install -d -m 0750 data backups
if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env. Edit it and set strong SECRET_KEY and MAIN_ADMIN_PASSWORD before starting."
fi
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
chmod +x start.sh zvm-tool.sh
venv/bin/python -m py_compile zvm.py docker_backend.py api.py kvm_backend.py node.py vps_animation_routes.py
echo "ZVM Panel dependencies installed. Edit .env, then run ./start.sh"
