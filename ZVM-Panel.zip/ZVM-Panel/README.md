# ZVM Panel

ZVM Panel is a Flask-based Docker/container hosting control panel. It is not a full hypervisor by itself. The Docker backend provisions containers; containers are **not full virtual machines**. For true virtual machines, configure a dedicated KVM/libvirt host and validate the experimental worker integration before production use.

## Requirements
- Ubuntu 22.04/24.04 or Debian 12/13
- Python 3.10+ and Docker Engine for container-backed instances
- Host-level administrative access for Docker/KVM setup
- A reverse proxy with HTTPS for public deployment

## Install (Ubuntu/Debian)
```bash
unzip ZVM-Panel.zip
cd ZVM-Panel
sudo ./install.sh
nano .env
```
Set a unique, long `SECRET_KEY`, strong `MAIN_ADMIN_PASSWORD`, correct email and database path. Do not publish `.env`. Then start:
```bash
./start.sh
```
Panel listens on `http://SERVER_IP:3000`. Put it behind HTTPS before exposing it to the Internet.

## Docker deployment
```bash
cp .env.example .env
# Edit .env and set unique secrets/passwords first.
mkdir -p data backups
docker compose up -d --build
docker compose logs -f zvm-panel
```
The compose file mounts `/var/run/docker.sock`, which effectively grants powerful control over the Docker host. Use only on a trusted server and restrict network access. Do not deploy this socket mount to an untrusted multi-tenant environment.

## Database isolation
The panel uses `zvm.db` by default (or `DATABASE_PATH`). Any legacy database was intentionally excluded from this distribution; no original user accounts, sessions or credentials are migrated. Back up `data/` before changing database paths. The app initializes its schema on startup.

## SSH and console
The project contains an SSH console implementation that opens connections from the server side. It requires valid SSH target details and a reachable SSH service. Test authorization, host-key verification, and session isolation on a controlled host before production use. Never put SSH private keys/passwords in client-side HTML. Do not assume an SSHX/tmate URL is an authenticated panel terminal.

## KVM
`kvm_backend.py` is an experimental helper, not a turnkey VM orchestration system. A production KVM deployment needs libvirt/QEMU on a dedicated host, image management, isolated networks, resource enforcement, and carefully scoped worker credentials.

## Files
- `zvm.py`: Flask application, routes, database initialization and console handlers
- `api.py`: REST API routes
- `docker_backend.py`: Docker container runtime
- `kvm_backend.py`: experimental KVM helper
- `node.py`: node agent
- `templates/`: separate Jinja templates, including admin and error pages
- `static/`: static assets
- `.env.example`: configuration template

## Validation
Run `python3 -m py_compile zvm.py api.py docker_backend.py kvm_backend.py node.py vps_animation_routes.py` and inspect logs before use. Features requiring a real Docker daemon, SSH target, or KVM/libvirt host cannot be fully verified by packaging-time checks.
