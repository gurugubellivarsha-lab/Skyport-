from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from . import db
from .models import User, Plan, VPS, Payment, AuditLog
from .services import provision, audit
from .proxmox import ProxmoxClient, ProxmoxError
bp = Blueprint("admin", __name__)

def admin_required():
    if not current_user.is_authenticated or current_user.role != "admin":
        abort(403)

@bp.get("/")
@login_required
def dashboard():
    admin_required()
    stats = {"users": User.query.count(), "vps": VPS.query.count(),
             "revenue": db.session.query(db.func.coalesce(db.func.sum(Payment.amount_paise), 0)).filter_by(status="approved").scalar(),
             "pending": Payment.query.filter_by(status="pending").count()}
    return render_template("admin.html", stats=stats, payments=Payment.query.order_by(Payment.created_at.desc()).all(),
                           vps=VPS.query.order_by(VPS.created_at.desc()).all(), plans=Plan.query.all(),
                           users=User.query.all())

@bp.post("/payments/<int:payment_id>/<decision>")
@login_required
def review_payment(payment_id, decision):
    admin_required()
    payment = db.session.get(Payment, payment_id)
    if not payment: abort(404)
    if decision not in ("approve", "reject"): abort(400)
    if payment.status != "pending":
        flash("Payment has already been reviewed."); return redirect(url_for("admin.dashboard"))
    payment.status = "approved" if decision == "approve" else "rejected"
    payment.reviewed_at, payment.reviewed_by = datetime.utcnow(), current_user.id
    payment.admin_note = request.form.get("note", "")[:500]
    db.session.commit()
    audit(current_user.id, f"payment.{decision}", str(payment.id))
    if decision == "approve":
        vm = provision(payment, current_user.id)
        flash(f"Payment approved. VPS record status: {vm.status}.")
    else:
        flash("Payment rejected.")
    return redirect(url_for("admin.dashboard"))

@bp.post("/plans")
@login_required
def create_plan():
    admin_required()
    try:
        p = Plan(name=request.form["name"][:100], cpu=max(1, min(64, int(request.form["cpu"]))),
                 ram_mb=max(512, min(1048576, int(request.form["ram_mb"]))),
                 disk_gb=max(5, min(100000, int(request.form["disk_gb"]))),
                 bandwidth_gb=max(1, int(request.form["bandwidth_gb"])),
                 price_paise=max(0, int(request.form["price_paise"])))
        db.session.add(p); db.session.commit()
        audit(current_user.id, "plan.created", str(p.id))
    except (ValueError, KeyError):
        db.session.rollback(); flash("Invalid plan values.")
    return redirect(url_for("admin.dashboard"))

@bp.post("/users/<int:user_id>/toggle")
@login_required
def toggle_user(user_id):
    admin_required()
    u = db.session.get(User, user_id)
    if not u or u.id == current_user.id: abort(400)
    u.active = not u.active; db.session.commit()
    audit(current_user.id, "user.active_changed", str(u.id), str(u.active))
    return redirect(url_for("admin.dashboard"))

@bp.get("/proxmox")
@login_required
def proxmox_status():
    admin_required()
    try:
        client = ProxmoxClient()
        nodes = client.nodes()
        return render_template("proxmox.html", nodes=nodes, error=None)
    except ProxmoxError as exc:
        return render_template("proxmox.html", nodes=[], error=str(exc))
