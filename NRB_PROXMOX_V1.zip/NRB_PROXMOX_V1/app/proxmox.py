"""Small Proxmox VE API client. Configure only a restricted API token."""
import os, requests
from urllib.parse import quote

class ProxmoxError(RuntimeError): pass

class ProxmoxClient:
    def __init__(self):
        self.base = os.getenv("PROXMOX_URL", "").rstrip("/")
        self.token_id = os.getenv("PROXMOX_TOKEN_ID", "")
        self.secret = os.getenv("PROXMOX_TOKEN_SECRET", "")
        self.verify = os.getenv("PROXMOX_VERIFY_SSL", "1") == "1"
        if not all((self.base, self.token_id, self.secret)):
            raise ProxmoxError("Proxmox connection is not configured.")
        self.session = requests.Session()
        self.session.headers["Authorization"] = f"PVEAPIToken={self.token_id}={self.secret}"
        self.session.verify = self.verify
        self.timeout = 20

    def request(self, method, path, **kwargs):
        try:
            r = self.session.request(method, self.base + "/api2/json" + path,
                                     timeout=self.timeout, **kwargs)
            r.raise_for_status()
            body = r.json()
            return body.get("data")
        except requests.RequestException as exc:
            raise ProxmoxError(f"Proxmox API request failed: {exc}") from exc
        except ValueError as exc:
            raise ProxmoxError("Proxmox returned invalid JSON.") from exc

    def nodes(self):
        return self.request("GET", "/nodes")

    def node_status(self, node):
        return self.request("GET", f"/nodes/{quote(node, safe='')}/status")

    def next_vmid(self):
        return int(self.request("GET", "/cluster/nextid"))

    def clone(self, node, template_vmid, new_vmid, name, storage=None):
        data = {"newid": new_vmid, "name": name, "full": 1}
        if storage:
            data["storage"] = storage
        return self.request("POST", f"/nodes/{quote(node, safe='')}/qemu/{template_vmid}/clone", data=data)

    def configure_vm(self, node, vmid, cpu, ram_mb, disk_gb, bridge):
        self.request("POST", f"/nodes/{quote(node, safe='')}/qemu/{vmid}/config",
                     data={"cores": cpu, "memory": ram_mb, "net0": f"virtio,bridge={bridge}"})
        # Disk expansion is intentionally not guessed: template disk naming/layout varies.
        # Configure disk size on a prepared template or implement a storage-specific resize.
        if disk_gb:
            self.request("POST", f"/nodes/{quote(node, safe='')}/qemu/{vmid}/resize",
                         data={"disk": os.getenv("PROXMOX_DISK_TARGET", "scsi0"),
                               "size": f"{disk_gb}G"})

    def task_status(self, node, upid):
        return self.request("GET", f"/nodes/{quote(node, safe='')}/tasks/{quote(upid, safe='')}/status")

    def power(self, node, vmid, action):
        if action not in {"start", "stop", "shutdown", "reboot"}:
            raise ProxmoxError("Unsupported power action.")
        return self.request("POST", f"/nodes/{quote(node, safe='')}/qemu/{vmid}/status/{action}")
